import 'package:admin_app/model/product_model.dart';
import 'package:admin_app/provider/category_provider.dart';
import 'package:admin_app/provider/product_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ProductsPage extends StatefulWidget {
  const ProductsPage({Key? key}) : super(key: key);

  @override
  _ProductsPageState createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  @override
  initState() {
    Provider.of<ProductProvider>(context, listen: false).getProduct(context);
    super.initState();
  }

  Widget build(BuildContext context) {
    var productsData = Provider.of<ProductProvider>(context).productList;
    return Scaffold(
      body: Container(
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: productsData.length,
          itemBuilder: (context, index) {
            return ListTile(
              leading: Image.network(
                  "https://homechef.antapp.space/images/${productsData[index].image}"),
              title: Text("${productsData[index].name}"),
              subtitle: Text("${productsData[index].price[0].discountedPrice}"),
            );
          },
        ),
      ),
    );
  }
}
