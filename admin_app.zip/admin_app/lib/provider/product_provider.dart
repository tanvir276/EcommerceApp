import 'package:admin_app/http/custom_http_request.dart';
import 'package:admin_app/model/product_model.dart';
import 'package:flutter/cupertino.dart';

class ProductProvider with ChangeNotifier {
  //Orders orders = Orders();
  List<Products> productList = [];

  getProduct(context) async {
    productList = await CustomHttpRequest.fetchProduct();
    notifyListeners();
  }
}
